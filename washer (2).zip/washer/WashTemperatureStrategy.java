package sw_FatroyMethod.washer;

// 세탁 온도 선택 전략 인터페이스
interface WashTemperatureStrategy {
    void selectTemperature();
}
