package sw_FatroyMethod.washer;

public interface Washer {
    // 세탁기를 나타내는 인터페이스
        void wash();

}
