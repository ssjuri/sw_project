package sw_FatroyMethod.washer;
// 세탁 온도를 나타내는 인터페이스
public interface WashTemperature {
    void setTemperature();
}
